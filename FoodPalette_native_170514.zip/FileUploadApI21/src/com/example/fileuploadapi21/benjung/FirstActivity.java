package com.example.fileuploadapi21.benjung;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Window;
import android.view.WindowManager;

public class FirstActivity extends Activity {
	
	Handler handler = new Handler(){
		public void handleMessage(Message msg) {
			Intent intent = new Intent(FirstActivity.this, MainActivity.class);
			startActivity(intent); //intent����
			overridePendingTransition(R.anim.fade, R.anim.fadeout);
			finish(); //�� Activity����
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		setContentView(R.layout.activity_first);
		
		new Thread(new Runnable(){
			public void run() {
				//�ð����� �� �ڵ鷯�� �ҷ��ش�.
				try{
					Thread.sleep(2500);//2.5ch
					Message message = handler.obtainMessage();
					handler.sendMessage(message);
					//�޼����� �ڵ鷯�� �ҷ���(��������ȯ)
				}catch(Exception e){}
			}
		}).start();
		
	}
}
